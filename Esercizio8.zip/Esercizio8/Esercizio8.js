//FUNZIONE AL CLICK DEL "CERCA" PER FAR APPARIRE LA BARRA DI RICERCA
document.getElementById("search").addEventListener("click", function(){
    let img = document.getElementById("search");
    let navSearch = document.getElementById("navSearch");
    if(navSearch.classList.contains("displayNone") === true){
        img.src = "assets/x-white.svg"
    }else{
        img.src = "assets/search-white.svg"
    }
    if(navSearch.classList.contains("displayNone") === true){
        navSearch.classList.remove("displayNone");
        navSearch.classList.add("animationFade");
    }else{
        navSearch.classList.add("displayNone");
    }
});


//AL CLICCO DI "GENRES" E' POSSIBILE CAMBIARE IL GENERE
document.getElementById("action").addEventListener("click", function(){
    document.getElementById("genres").innerText = "Action";
})
document.getElementById("comedy").addEventListener("click", function(){
    document.getElementById("genres").innerText = "Comedy";
})
document.getElementById("horror").addEventListener("click", function(){
    document.getElementById("genres").innerText = "Horror";
})
document.getElementById("thriller").addEventListener("click", function(){
    document.getElementById("genres").innerText = "Thriller";
})



//FUNZIONE PER METTERE I FILM IN GRIGLIA DA 4
function grid(){
    let arr = document.getElementsByClassName("cardsTop");
    document.getElementById("grid").style.backgroundColor = "gray"
    document.getElementById("alignLeft").style.backgroundColor = "black"
    for(let i = 0; i< arr.length; i++){
        arr[i].classList.remove("row-cols-xl-6");
        arr[i].classList.add("row-cols-xl-4");
    }
}

//FUNZIONE PER METTERE I FILM IN FILA A PARIRE DA SINISTRA
function alignLeft(){
    document.getElementById("alignLeft").style.backgroundColor = "gray"
    document.getElementById("grid").style.backgroundColor = "black"
    let arr = document.getElementsByClassName("cardsTop")
    for(let i = 0; i< arr.length; i++){
        arr[i].classList.remove("row-cols-xl-4");
        arr[i].classList.add("row-cols-xl-6");
    }

}


//FUNZIONE ONLOAD
function onL(){
    let trending = document.getElementById("trendingNow");
    trending.classList.remove("visibilityH");
    trending.classList.add("animationFade");
    let trendingCont = document.getElementById("contImgs1");
    trendingCont.classList.remove("visibilityH");
    trendingCont.classList.add("animationFadeCont");

    let watchItAgain = document.getElementById("wathcItAgain");
    watchItAgain.classList.remove("visibilityH");
    watchItAgain.classList.add("animationFade");
    let trendingCont2 = document.getElementById("contImgs2");
    trendingCont2.classList.remove("visibilityH");
    trendingCont2.classList.add("animationFadeCont");

    let newReleases = document.getElementById("newReleases");
    newReleases.classList.remove("visibilityH");
    newReleases.classList.add("animationFade");
    let contImgs3 = document.getElementById("contImgs3");
    contImgs3.classList.remove("visibilityH");
    contImgs3.classList.add("animationFadeCont");
}
window.onload = onL();
